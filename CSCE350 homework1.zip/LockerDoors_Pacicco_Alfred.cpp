// CSCE350 Alfred Pacicco
#include<iostream>
using std::cout;
using std::cin;
using std::endl;
  int l = 1;
  int p = 1;
  int num_open = 0;
  int open = 0; // 0 = false = closed, 1 = open;
int main() {
	
  cout << "Enter the number of lockers you'd like to create ";
  cin >> l;
  cout << endl;

  cout << "Enter the number of lockers you'd like to pass ";
  cin >> p;
	  if (l >= 1 && (p >= 1 && p < l)){
		for (int i = 1; i <= l; ++i){
		  if (i % p == 0){
		    open = 1;
			++num_open;
			cout << i << " " << "is open" << endl;
		  } else {
		    open = 0;
			cout << i << " " << "is closed" << endl;
		  }  
		}
		cout << "the number of open lockers: " << num_open << endl;
	  } else {
		cout << "Invalid input for lockers and/or passes" << endl;
	  }
  return 0;
}