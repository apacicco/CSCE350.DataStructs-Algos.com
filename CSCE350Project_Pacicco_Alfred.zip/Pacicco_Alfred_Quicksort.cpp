// CSCE350 Alfred Pacicco
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib> // For rand()
#include <ctime>   // For clock()

using namespace std;

//median of three values and return the index
int medianOfThree(double* arr, int left_num, int right_num) {
    int mid_num = (left_num + right_num) / 2;

    if (arr[left_num] > arr[mid_num]) swap(arr[left_num], arr[mid_num]);
    if (arr[left_num] > arr[right_num]) swap(arr[left_num], arr[right_num]);
    if (arr[mid_num] > arr[right_num]) swap(arr[mid_num], arr[right_num]);

    return mid_num;
}

//Quicksort 
void quickSort(double* arr, int left, int right) {
    if (left < right) {
        int pivotIndex = medianOfThree(arr, left, right);
        swap(arr[left], arr[pivotIndex]); // Move pivot to the leftmost position
        double pivot = arr[left];

        int i = left + 1;
        for (int j = left + 1; j <= right; ++j) {
            if (arr[j] < pivot) {
                swap(arr[i], arr[j]);
                i++;
            }
        }
        swap(arr[left], arr[i - 1]);
        int pivotFinal = i - 1;
        quickSort(arr, left, pivotFinal - 1);
        quickSort(arr, pivotFinal + 1, right);
    }
}

//read input from a file
double* readInputFile(const string& filename, int& size) {
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open input file!" << endl;
        exit(1);
    }
    string line;
    getline(inputFile, line);
    inputFile.close();
    size = 0;
    istringstream iss(line);
    double temp = 0;
    while (iss >> temp) {
        size++;
    }
    double* arr = new double[size];
    iss.clear();
    iss.str(line);
    for (int i = 0; i < size; ++i) {
        iss >> arr[i];
    }

    return arr;
}

//write execution time to a file
void writeExecutionTime(const string& filename, double timeMicroseconds) {
    ofstream timeFile(filename);
    if (!timeFile.is_open()) {
        cerr << "Error: Unable to open execution time file!" << endl;
        exit(1);
    }

    timeFile << timeMicroseconds << " microseconds";
    timeFile.close();
}


//write sorted numbers to a file
void writeOutputFile(const string& filename, double* arr, int size) {
    ofstream outputFile(filename);
    if (!outputFile.is_open()) {
        cerr << "Error: Unable to open output file!" << endl;
        exit(1);
    }

    for (int i = 0; i < size; ++i) {
        outputFile << arr[i];
        if (i != size - 1) outputFile << " ";
    }
    outputFile.close();
}

//generate random input file with random floating point numbers
void generateInputFile(const string& filename, int numValues) {
    ofstream outputFile(filename);
    if (!outputFile.is_open()) {
        cerr << "Error: Unable to create input file!" << endl;
        exit(1);
    }
    srand(time(0));

    //floating point numbers in the range [-100, 100]
    for (int i = 0; i < numValues; ++i) {
        double num = (rand() % 200 - 100) + ((rand() % 1000) / 1000.0); // Generate between -100.000 to 100.000
        outputFile << num;
        if (i != numValues - 1) outputFile << " ";
    }
    outputFile.close();
}

int main() {
    //names of files
    string inputFile = "input.txt";
    string outputFile = "output.txt";
    string timeFile = "execution_time.txt";

    //random input file with 1000 floating-point numbers
    generateInputFile(inputFile, 1000);

    int size;
    double* numbers = readInputFile(inputFile, size);

    clock_t start = clock();
    quickSort(numbers, 0, size - 1);
    clock_t end = clock();

    double executionTime = ((double)(end - start) / CLOCKS_PER_SEC);

    writeOutputFile(outputFile, numbers, size);
    writeExecutionTime(timeFile, executionTime);

    delete[] numbers;

    cout << "Sorting completed. Results written to files." << endl;

    return 0;
}
