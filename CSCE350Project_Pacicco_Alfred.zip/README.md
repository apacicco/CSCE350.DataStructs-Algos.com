# Project Title
CSCE350 final project - Alfred Pacicco

## Description
I've done the first half of this project. It generates an input file of 1000 values (between -100 & 100), partitions them based on the
median-of-three partitioning system, sorted them using quicksort, timed the sorting, and generated two files,
output & execution time, which contain the values sorted from smallest to largest and the length of time in which it took them to be
sorted, respectively. I've also attached a make file. 


## Installation
to activate the make file, type "make start". to clean it, type "make clean"

