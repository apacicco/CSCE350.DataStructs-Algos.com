//CSCE350 HW4 ALFRED PACICCO
#include<iostream>
using std::cout;
using std::cin;
using std::endl;

struct Node {
    int data;
    Node* left_child = nullptr;
    Node* right_child = nullptr;
};
//creating a new node
Node* createNode(int data)
{
    Node* newNode = new Node();
    newNode->data = data;
    newNode->left_child = newNode->right_child = nullptr;
    return newNode;
}
//inserting a node
Node* insertNode(Node* root, int data) {
    if (!root) {
        cout << "Node " << data << " has been inserted\n";
        return createNode(data);
    }
    
	if (data < root->data) {
        root->left_child = insertNode(root->left_child, data);
    } else if (data > root->data) {
        root->right_child = insertNode(root->right_child, data);
    } else {
        cout << "Node " << data << " is a duplicate node. Cannot insert Node " << data << " again\n";
    }
    return root;
}
//searching for a node
Node* searchNode(Node* root, int key) {
    if (!root) 
		return nullptr;
    cout << root->data << " -> ";
    
	if (root->data == key) 
		return root;
    return (key < root->data) ? searchNode(root->left_child, key) : searchNode(root->right_child, key);
}
//finding and returning the minimum node
Node* minDataNode(Node* node) {
    while (node && node->left_child) node = node->left_child;
    return node;
}
//finding and returning the maximum node
Node* maxDataNode(Node* node) {
    while (node && node->right_child) node = node->right_child;
    return node;
}
//deleting a node
Node* deleteNode(Node* root, int data) {
    if (!root) 
		return nullptr;
    if (data < root->data) 
		root->left_child = deleteNode(root->left_child, data);
    else if (data > root->data) 
		root->right_child = deleteNode(root->right_child, data);
    else {
        if (!root->left_child) {
            Node* temp = root->right_child;
            delete root;
            cout << "Node " << data << " has been deleted\n";
            return temp;
        }
        
		if (!root->right_child) {
            Node* temp = root->left_child;
            delete root;
            cout << "Node " << data << " has been deleted\n";
            return temp;
        }
        Node* temp = minDataNode(root->right_child);
        root->data = temp->data;
        root->right_child = deleteNode(root->right_child, temp->data);
    }
    return root;
}
// in-order traversal
void inorderTraversal(Node* root) {
    if (root) {
        inorderTraversal(root->left_child);
        cout << root->data << ", ";
        inorderTraversal(root->right_child);
    }
}

int main(){
	cout << "You have been given a tree already" << endl;
	Node* r = nullptr;
    int nodes[] = {5, 3, 1, 4, 7, 8};

    // intitial nodes
    for (int data : nodes) 
		r = insertNode(r, data);

    // inorder traversal
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << endl;
	int num = -1;
	do {
		cout << "\npress 1 to insert a node" << endl;
		cout << "press 2 to search for a node" << endl;
		cout << "press 3 to find the smallest node" << endl;
		cout << "press 4 to find the biggest node" << endl;
		cout << "press 5 to delete a node" << endl;
		cout << "press 0 to exit" << endl;
		cin >> num;
		
		
		if (num == 1){
			int guess = -1;
			cout << "what node would you like to insert" << endl;
			cin >> guess;
			r = insertNode(r, guess);
			cout << "BST nodes are: ";
			inorderTraversal(r);
			cout << endl;
		} else if (num == 2){
			int guess = -1;
			cout << "what node would you like to search for?" << endl;
			cin >> guess;
			cout << "Search path for node " << guess << ":\n ";
			Node* searchResult = searchNode(r, guess);
			
			if (!searchResult) 
				cout << "search key not found\n" << endl;
			else
				cout << "found";
			cout << "\n" << endl;
			inorderTraversal(r) ;
		} else if (num == 3) {
			Node* minNode = minDataNode(r);
			cout << "BST node with the smallest value:" << endl << "Node " << minNode->data << endl;
			inorderTraversal(r);
		}else if (num == 4) {
			Node* maxNode = maxDataNode(r);
			cout << "BST node with the largest value:" << endl << "Node " << maxNode->data << endl;
			inorderTraversal(r);
		} else if (num == 5) {
			int guess = -1;
			cout << "what node would you like to delete?" << endl;
			cin >> guess;
			r = deleteNode(r, guess);
			cout << "BST nodes are: ";
			inorderTraversal(r);
		} else 
			cout << "try again. invalid number" << endl;
		
			
	} while ( num != 0);
	cout << "appreciate the time!" << endl;
	return 0;
	
}

/*
int main() {
    Node* r = nullptr;
    int nodes[] = {5, 3, 1, 4, 7};

    // intitial nodes
    for (int data : nodes) 
		r = insertNode(r, data);

    // inorder traversal
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << endl;

    // test 1
    r = deleteNode(r, 4);
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << endl;

    // test 2
    r = insertNode(r, 2);
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << endl;

    // test 3
    r = insertNode(r, 7);
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << endl;

    // test 4
    r = insertNode(r, 6);
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << endl;

    // test 5
    r = deleteNode(r, 7);
    cout << "BST nodes are: ";
    inorderTraversal(r);
    cout << "at line 134" << endl;

    // test 6
    Node* minNode = minDataNode(r);
    cout << "BST node with the smallest value:" << endl << "Node " << minNode->data << endl;
	// test 7
	Node* maxNode = maxDataNode(r);
	cout << "BST node with the largest value:" << endl << "Node " << maxNode->data << endl;
    
	// test 8
    cout << "Search path for node 9: ";
    Node* searchResult = searchNode(r, 9);
    if (!searchResult) cout << "search key not found\n";
	
	
	cout << "BST nodes are: ";
	inorderTraversal(r);
	cout << endl;


    return 0;
}
*/